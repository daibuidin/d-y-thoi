# Tặng Crush
## _Một điều nho nhỏ tỏ tình với crush_

Liên lạc: 
[![Facebook](https://i.imgur.com/GRqy96ts.jpg)](https://www.facebook.com/nam.nodemy)
[![Tiktok](https://i.imgur.com/Nbfl1E7t.jpg)](https://www.tiktok.com/@manindev)

Mở file config.js sửa nội dung theo mẫu
```
const CONFIG = {
   introTitle: 'Hú Hú!❤️',
    introDesc: `Dậy thôi bạn ơi, gà gáy rát hết họng ròi 
    ngủ thế gà nào gáy cho nổi🐓. `,
    btnIntro: 'Nhấn vảo đây nè 🌥️',
    title: 'Dậy sớm để thành công nào đồng chí!!  😙',
    desc: 'Ngủ méo ngủ lắm 🙏🙏🙏  ',
    btnYes: 'Có!Đang dậy rồi đây 😽 ',
    btnNo: 'Đéo 🖕',
    question:'Biết sao gọi dậy sớm không ? 👉👈',
    btnReply: 'Gửi đại ca 💌',
    reply: 'Yêu thì yêu mà không yêu thì yêu <33333333',
    mess: 'Anh thích anh gọi được không kkk 😝😝',
    messDesc: 'lêu lêu 😝. Lo mà dậy ăn uống đe.',
    btnAccept: 'Ờ 🖕',
    messLink: 'http://fb.com' //link mess của các bạn. VD: https://m.me/nam.nodemy
}
```

