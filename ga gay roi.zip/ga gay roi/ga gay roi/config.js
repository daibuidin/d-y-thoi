const CONFIG = {
    introTitle: 'Hú Hú!❤️',
    introDesc: `Dậy thôi bạn ơi, gà gáy rát hết họng ròi 
    ngủ thế gà nào gáy cho nổi🐓. `,
    btnIntro: 'Nhấn vảo đây nè 🌥️',
    title: 'Dậy sớm để thành công nào đồng chí!!  😙',
    desc: 'Ngủ méo ngủ lắm 🙏🙏🙏  ',
    btnYes: 'Có!Đang dậy rồi đây 😽 ',
    btnNo: 'Đéo 🖕',
    question:'Biết sao gọi dậy sớm không ? 👉👈',
    btnReply: 'Gửi đại ca 💌',
    reply: 'Yêu thì yêu mà không yêu thì yêu <33333333',
    mess: 'Anh thích anh gọi được không kkk 😝😝',
    messDesc: 'lêu lêu 😝. Lo mà dậy ăn uống đe.',
    btnAccept: 'Nhấn vào để phản hồi🖕',
    messLink: 'https://www.messenger.com/e2ee/t/8070647702978026' //link mess của các bạn. VD: https://m.me/nam.nodemy
}